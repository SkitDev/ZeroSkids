from .obfuscator import obfuscate

__all__ = ['obfuscate']
