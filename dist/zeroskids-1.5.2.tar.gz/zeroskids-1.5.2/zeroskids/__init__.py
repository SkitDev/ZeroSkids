from .obfuscator import obfuscate, ultra_obfuscate

__all__ = ['obfuscate', 'ultra_obfuscate']
