# tests for core logic
